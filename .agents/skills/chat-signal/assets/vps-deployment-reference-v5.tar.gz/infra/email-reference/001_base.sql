BEGIN;

CREATE TABLE IF NOT EXISTS workspaces (
  id text PRIMARY KEY,
  name text NOT NULL,
  timezone text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS channel_accounts (
  id text PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  provider text NOT NULL CHECK (provider = 'evolution'),
  external_account_id text NOT NULL,
  display_name text NOT NULL,
  connection_state text NOT NULL DEFAULT 'unknown'
    CHECK (connection_state IN ('connected', 'disconnected', 'degraded', 'unknown')),
  last_seen_at timestamptz,
  gap_since_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, provider, external_account_id),
  UNIQUE (workspace_id, id)
);

CREATE TABLE IF NOT EXISTS channel_identities (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL REFERENCES channel_accounts(id),
  external_chat_id text NOT NULL,
  display_name text,
  twenty_company_id text,
  twenty_person_id text,
  mapped_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, channel_account_id, external_chat_id)
);

CREATE TABLE IF NOT EXISTS webhook_events (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL REFERENCES channel_accounts(id),
  provider_event_id text NOT NULL,
  event_name text NOT NULL,
  raw_hash text NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, channel_account_id, provider_event_id, event_name)
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL REFERENCES channel_accounts(id),
  identity_id uuid NOT NULL REFERENCES channel_identities(id),
  external_message_id text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  occurred_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  message_type text NOT NULL,
  body_text text,
  quoted_external_message_id text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, channel_account_id, external_message_id)
);

CREATE TABLE IF NOT EXISTS attachments (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  message_id uuid NOT NULL REFERENCES messages(id),
  external_attachment_id text,
  mime_type text,
  file_name text,
  size_bytes bigint,
  sha256 text,
  processing_status text NOT NULL
    CHECK (processing_status IN ('pending', 'ready', 'blocked', 'failed')),
  gap_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, message_id, external_attachment_id)
);

CREATE INDEX IF NOT EXISTS idx_messages_workspace_time
  ON messages(workspace_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS idx_attachments_workspace_status
  ON attachments(workspace_id, processing_status);

COMMIT;
