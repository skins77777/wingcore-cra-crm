BEGIN;

CREATE TABLE IF NOT EXISTS message_revisions (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  message_id uuid NOT NULL REFERENCES messages(id),
  revision_number integer NOT NULL CHECK (revision_number > 0),
  change_kind text NOT NULL CHECK (change_kind IN ('edited', 'deleted')),
  body_text text,
  occurred_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now(),
  raw_hash text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, message_id, revision_number),
  UNIQUE (workspace_id, id)
);

CREATE TABLE IF NOT EXISTS evidence_changes (
  cursor bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  source_key text NOT NULL UNIQUE,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  identity_id uuid NOT NULL REFERENCES channel_identities(id),
  message_id uuid NOT NULL REFERENCES messages(id),
  revision_id uuid REFERENCES message_revisions(id),
  change_kind text NOT NULL CHECK (change_kind IN ('message', 'edited', 'deleted')),
  occurred_at timestamptz NOT NULL,
  received_at timestamptz NOT NULL
);

CREATE OR REPLACE FUNCTION append_message_evidence_change()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO evidence_changes (
    source_key, workspace_id, identity_id, message_id, revision_id,
    change_kind, occurred_at, received_at
  ) VALUES (
    'message:' || NEW.id::text, NEW.workspace_id, NEW.identity_id, NEW.id, NULL,
    'message', NEW.occurred_at, NEW.received_at
  ) ON CONFLICT (source_key) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE FUNCTION append_revision_evidence_change()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO evidence_changes (
    source_key, workspace_id, identity_id, message_id, revision_id,
    change_kind, occurred_at, received_at
  )
  SELECT
    'revision:' || NEW.id::text, NEW.workspace_id, m.identity_id, NEW.message_id,
    NEW.id, NEW.change_kind, NEW.occurred_at, NEW.received_at
  FROM messages m
  WHERE m.workspace_id = NEW.workspace_id AND m.id = NEW.message_id
  ON CONFLICT (source_key) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE OR REPLACE TRIGGER trg_p2_message_change
AFTER INSERT ON messages
FOR EACH ROW EXECUTE FUNCTION append_message_evidence_change();

CREATE OR REPLACE TRIGGER trg_p2_revision_change
AFTER INSERT ON message_revisions
FOR EACH ROW EXECUTE FUNCTION append_revision_evidence_change();

INSERT INTO evidence_changes (
  source_key, workspace_id, identity_id, message_id, revision_id,
  change_kind, occurred_at, received_at
)
SELECT
  'message:' || id::text, workspace_id, identity_id, id, NULL,
  'message', occurred_at, received_at
FROM messages
ON CONFLICT (source_key) DO NOTHING;

COMMIT;
