BEGIN;

ALTER TABLE email_messages
  ADD COLUMN IF NOT EXISTS reply_to_addresses jsonb NOT NULL DEFAULT '[]'::jsonb;

ALTER TABLE email_messages
  ALTER COLUMN reply_to_addresses DROP DEFAULT;

COMMIT;
