BEGIN;

ALTER TABLE channel_accounts
  DROP CONSTRAINT IF EXISTS channel_accounts_provider_check;
ALTER TABLE channel_accounts
  ADD CONSTRAINT channel_accounts_provider_check
  CHECK (provider IN ('evolution', 'imap'));

CREATE TABLE IF NOT EXISTS email_sync_cursors (
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL,
  mailbox_role text NOT NULL CHECK (mailbox_role IN ('inbox', 'sent')),
  mailbox_path text NOT NULL,
  uid_validity text,
  last_uid bigint NOT NULL DEFAULT 0 CHECK (last_uid >= 0),
  initial_sync_after timestamptz NOT NULL,
  last_successful_at timestamptz,
  last_error_code text,
  updated_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, channel_account_id, mailbox_role),
  FOREIGN KEY (workspace_id, channel_account_id)
    REFERENCES channel_accounts(workspace_id, id)
);

CREATE TABLE IF NOT EXISTS email_messages (
  id uuid PRIMARY KEY,
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL,
  message_id uuid UNIQUE REFERENCES messages(id),
  rfc_message_id text NOT NULL,
  direction text NOT NULL CHECK (direction IN ('inbound', 'outbound')),
  primary_identity_address text,
  analysis_status text NOT NULL CHECK (analysis_status IN ('eligible', 'ignored', 'review_required')),
  analysis_reason text,
  classification text NOT NULL CHECK (classification IN ('human', 'bulk', 'bounce', 'system')),
  subject text NOT NULL,
  from_addresses jsonb NOT NULL,
  to_addresses jsonb NOT NULL,
  cc_addresses jsonb NOT NULL,
  reply_to_addresses jsonb NOT NULL,
  in_reply_to text,
  reference_ids jsonb NOT NULL,
  thread_key text NOT NULL,
  background_complete boolean NOT NULL,
  body_text text,
  attachments jsonb NOT NULL,
  source_truncated boolean NOT NULL DEFAULT false,
  source_sha256 text NOT NULL CHECK (source_sha256 ~ '^[0-9a-f]{64}$'),
  occurred_at timestamptz NOT NULL,
  first_seen_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (workspace_id, channel_account_id, rfc_message_id),
  FOREIGN KEY (workspace_id, channel_account_id)
    REFERENCES channel_accounts(workspace_id, id)
);

CREATE TABLE IF NOT EXISTS email_message_copies (
  workspace_id text NOT NULL REFERENCES workspaces(id),
  channel_account_id text NOT NULL,
  email_message_id uuid NOT NULL REFERENCES email_messages(id),
  mailbox_role text NOT NULL CHECK (mailbox_role IN ('inbox', 'sent')),
  mailbox_path text NOT NULL,
  uid_validity text NOT NULL,
  uid bigint NOT NULL CHECK (uid > 0),
  first_seen_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, channel_account_id, mailbox_path, uid_validity, uid),
  UNIQUE (email_message_id, mailbox_path, uid_validity, uid),
  FOREIGN KEY (workspace_id, channel_account_id)
    REFERENCES channel_accounts(workspace_id, id)
);

CREATE INDEX IF NOT EXISTS idx_email_messages_thread
  ON email_messages(workspace_id, channel_account_id, thread_key, occurred_at);
CREATE INDEX IF NOT EXISTS idx_email_messages_review
  ON email_messages(workspace_id, analysis_status, occurred_at DESC);

DO $migration$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'crm_runtime') THEN
    GRANT SELECT, INSERT, UPDATE ON email_sync_cursors TO crm_runtime;
    GRANT SELECT, INSERT, UPDATE ON email_messages TO crm_runtime;
    GRANT SELECT, INSERT, UPDATE ON email_message_copies TO crm_runtime;
  END IF;
END
$migration$;

COMMIT;
