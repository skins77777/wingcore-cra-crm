#!/usr/bin/python3
"""Daily local recovery snapshots. Never deletes old backups automatically."""
import datetime
import hashlib
import json
import pathlib
import subprocess
import os
import tarfile

os.umask(0o077)
root = pathlib.Path('/root/backups/crm-daily')
dest = root / datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
dest.mkdir(parents=True, mode=0o700)
for container, name in [('crm-automation-postgres-1', 'automation'), ('twenty-vps-postgres-1', 'twenty')]:
    config = json.loads(subprocess.check_output(['docker', 'inspect', container]))[0]
    env = dict(item.split('=', 1) for item in config['Config']['Env'] if '=' in item)
    with (dest / (name + '.dump')).open('wb') as handle:
        subprocess.run(['docker', 'exec', container, 'pg_dump', '-U', env['POSTGRES_USER'], '-d', env['POSTGRES_DB'], '-Fc'], stdout=handle, check=True)
with (dest / 'automation-roles.sql').open('wb') as handle:
    subprocess.run(['docker', 'exec', 'crm-automation-postgres-1', 'pg_dumpall', '-U', 'crm_owner', '--globals-only'], stdout=handle, check=True)
for source, name in [('/etc/crm-automation/runtime.env', 'runtime.env'), ('/root/twenty-vps/.env', 'twenty.env'), ('/root/crm-automation/.env', 'automation.env')]:
    (dest / name).write_bytes(pathlib.Path(source).read_bytes())
storage = json.loads(subprocess.check_output(['docker', 'volume', 'inspect', 'twenty-vps_server-data']))[0]['Mountpoint']
with tarfile.open(dest / 'twenty-storage.tar.gz', 'w:gz') as archive:
    archive.add(storage, arcname='storage')
manifest = {file.name: hashlib.sha256(file.read_bytes()).hexdigest() for file in dest.iterdir() if file.is_file()}
(dest / 'sha256.json').write_text(json.dumps(manifest, indent=2))
print(json.dumps({'event': 'crm.backup.succeeded', 'directory': str(dest), 'files': len(manifest)}))
