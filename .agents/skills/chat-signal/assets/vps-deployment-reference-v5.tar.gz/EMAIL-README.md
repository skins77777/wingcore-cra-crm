# 邮箱读取参考（v5）

这是 VPS 邮箱接入模块的脱敏源码与依赖，不含客户邮箱、授权码、邮件记录或附件。v5 新补入的邮件源码经过本地审阅；此前 13 个 VPS 文件的在线核对记录不覆盖这些新增文件。

## 包含什么

| 文件 | 职责 |
| --- | --- |
| `apps/vps/src/email-sync.ts` | IMAP 配置、连接、收件箱与已发送同步、UID 游标、失败状态 |
| `packages/connectors/src/imap-email.ts` | MIME 解析、地址规范化、身份判断、自动邮件过滤、邮件串与证据格式 |
| `packages/persistence/src/email-postgres.ts` | 渠道账号、游标、邮件副本去重、客户身份与证据入库 |
| `packages/contracts/src/email.ts` | 以上模块共用的类型 |
| `apps/vps/src/email-sync.test.ts`、`packages/connectors/src/imap-email.test.ts` | 12 项配置、解析、身份和线程规则测试；全部使用虚构样例 |
| `infra/email-reference/001_base.sql`、`002_evidence.sql` | 邮件模块所需基础表和证据变更表/触发器，从原迁移中截取；移除原工作区与账号种子数据 |
| `infra/vps/011_email_imap.sql`、`012_email_reply_to.sql` | IMAP 邮件、同步游标、副本和 Reply-To 结构 |
| `infra/vps/runtime.env.email.example` | 邮箱配置占位模板；默认关闭 |
| `package.json`、`package-lock.json`、`tsconfig.email.json` | 邮件子集依赖、锁文件和独立类型检查范围 |

## 独立验证代码

在解压后的新目录中，用 Node >= 24.15.0 执行：

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run typecheck:email
npm run test:email
```

这三步不连接邮箱或数据库，也不运行原 `run.ts`。测试使用合成 MIME 内容；不证明真实邮箱连接、数据库集成或客户部署已经验收。直接依赖版本来自原项目已解析版本；npm 锁文件为这份邮件子集生成，不代表整套生产依赖完全一致。

## 接入客户 VPS

由客户完整后台的执行器调用导出的 `readImapRuntimeConfig(env)` 与 `syncImapEmail(database, env, now?)`。原 `apps/vps/src/run.ts` 展示集成位置，但它还导入未附带的模型、审核和 CRM 模块，不能仅凭本包启动。邮箱同步本身不调用模型或 Twenty API。

在隔离的新建参考数据库中，结构顺序为：`001_base.sql` → `002_evidence.sql` → `011_email_imap.sql` → `012_email_reply_to.sql`。本包不创建客户工作区或运行角色；实施时先建立客户自己的工作区，再配置同一 `P3_WORKSPACE_ID`、邮箱账号 ID 和私有数据库连接。用数据库所有者执行结构脚本后，须按实际运行角色补齐基础表、邮件表和证据序列的最小权限。`011` 仅在 `crm_runtime` 已存在时对邮件三表授权，不代表全部权限已经配置。

已有生产数据库沿用完整后台的迁移记录，不要把这两个截取的基础 SQL 当成新增生产迁移重复套用。它们不包含后续 AI 分析、审批、Outbox 或完整 CRM 数据结构。

邮箱连接配置参见 `infra/vps/runtime.env.email.example`，数据库与工作区变量参见根目录 `runtime.env.example`。`EMAIL_IMAP_ENABLED` 由调用方执行器检查；直接调用同步函数不会替调用方检查总开关。运行时必须沿用主执行器的工作区 advisory lock，避免多个执行器同时处理同一工作区；不要同时启动第二套定时消费。

首次回看固定 30 天，随后按 UID 增量同步；邮箱路径或 UIDVALIDITY 变化时按持久化边界处理。必须能够定位已发送目录，必要时设置 `EMAIL_IMAP_SENT_PATH`。邮箱以只读方式打开，不发送邮件、删除邮件或标记已读。

原始 MIME 会被获取和解析，可能含附件字节；持久化仅保留附件元数据和未提取标记，没有 OCR/附件语义识别或附件文件归档。歧义身份记为 `review_required`，这不是独立可用的人工审核页面。可信网站表单转发需显式配置来源，并满足 Reply-To 与正文邮箱一致等代码条件。

上线前在客户授权的邮箱和隔离数据库验证连接、收发方向、已发送目录、重复投递、游标续跑、权限和失败恢复，再验证完整后台的证据消费、模型分析与 CRM 链路。此包没有代替这些环境验收。
