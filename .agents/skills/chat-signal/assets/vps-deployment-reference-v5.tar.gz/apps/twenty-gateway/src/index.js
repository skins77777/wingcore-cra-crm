/** @type {ExportedHandler<Env>} */
export default {
  async fetch(request, env) {
    const incoming = new URL(request.url);
    if (incoming.hostname !== env.PUBLIC_HOST) {
      return new Response("Not found", { status: 404 });
    }

    // Fix the destination: neither request headers nor paths can select a host.
    const target = new URL("http://127.0.0.1:3002");
    target.pathname = incoming.pathname;
    target.search = incoming.search;
    const headers = new Headers(request.headers);
    headers.set("Host", env.PUBLIC_HOST);
    headers.set("X-Forwarded-Host", env.PUBLIC_HOST);
    headers.set("X-Forwarded-Proto", "https");
    headers.set("X-Forwarded-Port", "443");
    headers.delete("Forwarded");
    headers.delete("X-Real-IP");
    headers.delete("X-Forwarded-For");
    const clientIp = request.headers.get("CF-Connecting-IP");
    if (clientIp) headers.set("X-Forwarded-For", clientIp);

    try {
      const upstream = await env.TWENTY_ORIGIN.fetch(
        new Request(target, {
          method: request.method,
          headers,
          body: request.body,
          redirect: "manual",
        }),
      );
      if (upstream.status === 101) return upstream;
      // Keep SSE and file downloads streaming. Never buffer CRM payloads.
      const response = new Response(upstream.body, upstream);
      response.headers.set("Cache-Control", "private, no-store");
      response.headers.set("X-Robots-Tag", "noindex, nofollow");
      return response;
    } catch {
      console.error(JSON.stringify({ event: "twenty_origin_unavailable" }));
      return new Response("Twenty is temporarily unavailable. Please retry.", {
        status: 502,
        headers: { "Cache-Control": "no-store" },
      });
    }
  },
};
