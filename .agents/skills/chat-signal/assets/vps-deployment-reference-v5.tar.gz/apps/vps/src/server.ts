import { createServer, type IncomingMessage } from 'node:http';
import edge from '../../edge/src/index.ts';
import { handleP3ReviewFetch } from '../../edge/src/p3-review-worker.ts';

export async function requestFromNode(req: IncomingMessage): Promise<Request> {
  const chunks: Buffer[] = [];
  let length = 0;
  for await (const chunk of req) {
    length += chunk.length;
    if (length > 1_000_000) throw new RangeError('BODY_LIMIT');
    chunks.push(chunk);
  }
  return new Request(`http://localhost${req.url}`, {
    method: req.method ?? 'GET',
    headers: req.headers as Record<string, string>,
    ...(!['GET', 'HEAD'].includes(req.method ?? 'GET') ? { body: Buffer.concat(chunks) } : {}),
  });
}

export function createAutomationServer(environment: NodeJS.ProcessEnv) {
  const env = { ...environment, HYPERDRIVE: { connectionString: environment.P3_DATABASE_URL } };
  return createServer(async (req, res) => {
    try {
      const request = await requestFromNode(req);
      const path = new URL(request.url).pathname;
      const response = path.startsWith('/v1/p3/')
        ? await handleP3ReviewFetch(request, env as any)
        : await edge.fetch!(request as any, env as any, {} as any);
      const headers: Record<string,string> = {};
      response.headers.forEach((value,key)=>{headers[key]=value;});
      res.writeHead(response.status, headers);
      res.end(Buffer.from(await response.arrayBuffer()));
    } catch (error) {
      const status = error instanceof RangeError ? 413 : 500;
      console.error(JSON.stringify({event: 'crm.http.failed', status}));
      res.writeHead(status, {'content-type': 'application/json'});
      res.end(JSON.stringify({error: status === 413 ? 'BODY_LIMIT' : 'INTERNAL_ERROR'}));
    }
  });
}

if (import.meta.main) {
  for (const key of ['P3_DATABASE_URL', 'P1_WORKSPACE_ID', 'P1_ACCOUNT_ID', 'P1_WEBHOOK_SECRET', 'P1_API_TOKEN', 'P3_REVIEW_API_TOKEN']) {
    if (!process.env[key]) throw new Error(`Missing ${key}`);
  }
  const server = createAutomationServer(process.env);
  // Bind only to loopback and the existing Evolution bridge gateway, never public interfaces.
  const servers = [server];
  server.listen(3100, '127.0.0.1');
  if (process.env.CRM_EVOLUTION_BRIDGE_HOST) {
    const bridgeServer = createAutomationServer(process.env);
    bridgeServer.listen(3100, process.env.CRM_EVOLUTION_BRIDGE_HOST);
    servers.push(bridgeServer);
  }
  for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => {
    for (const item of servers) item.close();
  });
}
