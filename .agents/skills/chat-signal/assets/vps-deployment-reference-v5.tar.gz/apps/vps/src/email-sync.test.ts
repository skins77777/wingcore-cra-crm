import assert from "node:assert/strict";
import test from "node:test";

import { emailSyncErrorCode, readImapRuntimeConfig } from "./email-sync.ts";

const env = {
  P3_WORKSPACE_ID: "workspace",
  EMAIL_IMAP_ACCOUNT_ID: "imap-account",
  EMAIL_IMAP_HOST: "imap.example.com",
  EMAIL_IMAP_USER: "Sales@Example.com",
  EMAIL_IMAP_PASSWORD: "authorization-code",
};

test("IMAP runtime defaults to a fixed 30-day lookback and read-only TLS endpoint", () => {
  const config = readImapRuntimeConfig(env);
  assert.equal(config.initialLookbackDays, 30);
  assert.equal(config.port, 993);
  assert.equal(config.secure, true);
  assert.deepEqual([...config.ownAddresses], ["sales@example.com"]);
});

test("all aliases are normalized and can be configured without exposing credentials", () => {
  const config = readImapRuntimeConfig({
    ...env,
    EMAIL_IMAP_OWN_ADDRESSES: "sales@example.com, Alias@Example.com",
    EMAIL_IMAP_WEBFORM_RELAY_ADDRESSES: "Sales@Example.com",
  });
  assert.deepEqual([...config.ownAddresses], ["sales@example.com", "alias@example.com"]);
  assert.deepEqual([...config.webformRelayAddresses], ["sales@example.com"]);
});

test("lookback cannot silently drift beyond the approved 30 days", () => {
  assert.throws(() => readImapRuntimeConfig({ ...env, EMAIL_IMAP_INITIAL_LOOKBACK_DAYS: "31" }), /MUST_BE_30/);
  assert.throws(() => readImapRuntimeConfig({ ...env, EMAIL_IMAP_OWN_ADDRESSES: "sales@example.com,not-an-email" }), /OWN_ADDRESSES_INVALID/);
  assert.throws(() => readImapRuntimeConfig({ ...env, EMAIL_IMAP_SECURE: "yes" }), /SECURE_INVALID/);
  assert.throws(() => readImapRuntimeConfig({ ...env, EMAIL_IMAP_WEBFORM_RELAY_ADDRESSES: "not-an-email" }), /WEBFORM_RELAY_ADDRESSES_INVALID/);
});

test("operational errors are reduced to secret-free stable codes", () => {
  assert.equal(emailSyncErrorCode(new Error("authentication failed for hidden user")), "EMAIL_IMAP_AUTH_FAILED");
  assert.equal(emailSyncErrorCode(new Error("socket ETIMEDOUT")), "EMAIL_IMAP_TIMEOUT");
  assert.equal(emailSyncErrorCode(new Error("unexpected server reply")), "EMAIL_IMAP_SYNC_FAILED");
});
