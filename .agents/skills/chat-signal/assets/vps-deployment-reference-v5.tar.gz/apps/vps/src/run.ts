import {applyBusinessReviewDecisions} from './business-reviews.ts';
import {ReviewedCrmOutbox} from '../../../packages/persistence/src/reviewed-crm-outbox.ts';
import {Client} from 'pg';
import {DeepSeekAdapter} from '../../../packages/ai/src/deepseek.ts';
import {processP2QueueMessage} from '../../edge/src/p2-postgres.ts';
import {dispatchOneCrmWrite} from '../../../packages/crm/src/dispatcher.ts';
import {TwentyRestClient} from '../../../packages/crm/src/twenty-rest.ts';
import {PostgresCrmOutbox} from '../../../packages/persistence/src/crm-outbox-postgres.ts';
import {planAutomaticWrites} from './planner.ts';
import {importUniqueIdentities} from './import-identities.ts';
import {emailSyncErrorCode,syncImapEmail} from './email-sync.ts';

const env=process.env;
const client=new Client({connectionString:env.P3_DATABASE_URL});
await client.connect();
try {
  const lock=await client.query<{locked:boolean}>('SELECT pg_try_advisory_lock(hashtext($1)) AS locked',[`vps-crm:${env.P3_WORKSPACE_ID}`]);
  if(!lock.rows[0]?.locked)console.log(JSON.stringify({event:'crm.run.busy'}));
  else {
    if(env.EMAIL_IMAP_ENABLED==='1') {
      try {
        const email=await syncImapEmail(client,env);
        console.log(JSON.stringify({event:'crm.email.synced',...email}));
      } catch(error) {
        // Email collection failures are isolated: existing WhatsApp analysis,
        // approval and outbox recovery must continue on the same minute run.
        console.error(JSON.stringify({event:'crm.email.failed',code:emailSyncErrorCode(error)}));
      }
    }
    if(env.CRM_ANALYSIS_ENABLED==='1') {
      console.log(JSON.stringify({event:'crm.identities.imported',count:await importUniqueIdentities(client,env)}));
      const model=new DeepSeekAdapter({apiKey:env.P2_DEEPSEEK_API_KEY!,baseUrl:env.P2_DEEPSEEK_BASE_URL!,model:env.P2_DEEPSEEK_MODEL!,maximumContextBytes:120000,maximumOutputTokens:8192,maximumTotalTokensPerAnalysis:120000});
      const analysis=await processP2QueueMessage(client,model,{kind:'schedule',scheduledAt:new Date().toISOString(),source:'cron'}, {textOnly:true,workspaceId:env.P3_WORKSPACE_ID!,leaseSeconds:1200,maxAttempts:3,maxBatchesPerRun:1,maxUnitsPerRun:1,modelName:env.P2_DEEPSEEK_MODEL!});
      console.log(JSON.stringify({event:'crm.analysis',...analysis}));
    }
    if(env.CRM_AUTOMATION_ENABLED==='1'&&env.P3_CRM_WRITES_ENABLED==='1') {
      if(!env.CRM_AUTOMATION_SINCE)throw new Error('CRM_AUTOMATION_SINCE_REQUIRED');
      const twenty=new TwentyRestClient({baseUrl:env.TWENTY_BASE_URL!,apiKey:env.TWENTY_API_KEY!});
      await applyBusinessReviewDecisions(client,env);
      const queue=new ReviewedCrmOutbox(client);
      for(let step=0;step<12;step++) {
        const plans=await planAutomaticWrites(client,env);
        const dispatched=await dispatchOneCrmWrite(queue,twenty,{workspaceId:env.P3_WORKSPACE_ID!,workerId:`vps-${process.pid}`,leaseSeconds:120,maxAttempts:5,retryDelaySeconds:60});
        console.log(JSON.stringify({event:'crm.write',...plans,...dispatched}));
        if(dispatched.status==='idle')break;
        if(['failed','conflict','lost_lease'].includes(dispatched.status)){process.exitCode=1;break;}
      }
    }
  }
} catch(error) {
  console.error(JSON.stringify({event:'crm.run.failed',code:error instanceof Error?error.name:'UNKNOWN',databaseCode:(error as any)?.code??null}));
  process.exitCode=1;
} finally {await client.end();}
