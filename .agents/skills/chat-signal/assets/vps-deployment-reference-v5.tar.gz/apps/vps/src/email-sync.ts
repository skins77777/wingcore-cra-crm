import { ImapFlow } from "imapflow";
import type { Client } from "pg";

import type { EmailMailboxRole } from "../../../packages/contracts/src/email.ts";
import { normalizeEmailAddress, parseImapMessage } from "../../../packages/connectors/src/imap-email.ts";
import {
  advanceEmailSyncCursor,
  ingestEmailMessage,
  loadEmailSyncCursor,
  markImapAccountConnected,
  recordEmailSyncFailure,
  refreshEmailThreads,
  upsertImapChannelAccount,
} from "../../../packages/persistence/src/email-postgres.ts";

interface ImapRuntimeConfig {
  workspaceId: string;
  accountId: string;
  host: string;
  port: number;
  secure: boolean;
  user: string;
  password: string;
  ownAddresses: Set<string>;
  webformRelayAddresses: Set<string>;
  inboxPath: string;
  sentPath: string | null;
  initialLookbackDays: number;
  maximumMessageBytes: number;
}

type Environment = Record<string, string | undefined>;

function required(env: Environment, name: string): string {
  const value = env[name]?.trim();
  if (!value) throw new Error(`${name}_REQUIRED`);
  return value;
}

export function readImapRuntimeConfig(env: Environment): ImapRuntimeConfig {
  const user = required(env, "EMAIL_IMAP_USER");
  const rawAddresses = (env.EMAIL_IMAP_OWN_ADDRESSES ?? user).split(",").map((item) => item.trim()).filter(Boolean);
  const configuredAddresses = rawAddresses.map(normalizeEmailAddress);
  if (!configuredAddresses.length || configuredAddresses.some((item) => !item)) throw new Error("EMAIL_IMAP_OWN_ADDRESSES_INVALID");
  const rawRelays = (env.EMAIL_IMAP_WEBFORM_RELAY_ADDRESSES ?? "").split(",").map((item) => item.trim()).filter(Boolean);
  const configuredRelays = rawRelays.map(normalizeEmailAddress);
  if (configuredRelays.some((item) => !item)) throw new Error("EMAIL_IMAP_WEBFORM_RELAY_ADDRESSES_INVALID");
  const port = Number(env.EMAIL_IMAP_PORT ?? "993");
  const lookback = Number(env.EMAIL_IMAP_INITIAL_LOOKBACK_DAYS ?? "30");
  const maximumMessageBytes = Number(env.EMAIL_IMAP_MAX_MESSAGE_BYTES ?? String(25 * 1024 * 1024));
  if (!Number.isSafeInteger(port) || port < 1 || port > 65535) throw new Error("EMAIL_IMAP_PORT_INVALID");
  if (!['0','1'].includes(env.EMAIL_IMAP_SECURE ?? '1')) throw new Error("EMAIL_IMAP_SECURE_INVALID");
  if (!Number.isSafeInteger(lookback) || lookback !== 30) throw new Error("EMAIL_IMAP_INITIAL_LOOKBACK_DAYS_MUST_BE_30");
  if (!Number.isSafeInteger(maximumMessageBytes) || maximumMessageBytes < 1024 * 1024 || maximumMessageBytes > 100 * 1024 * 1024) throw new Error("EMAIL_IMAP_MAX_MESSAGE_BYTES_INVALID");
  return {
    workspaceId: required(env, "P3_WORKSPACE_ID"),
    accountId: required(env, "EMAIL_IMAP_ACCOUNT_ID"),
    host: required(env, "EMAIL_IMAP_HOST"),
    port,
    secure: (env.EMAIL_IMAP_SECURE ?? "1") === "1",
    user,
    password: required(env, "EMAIL_IMAP_PASSWORD"),
    ownAddresses: new Set(configuredAddresses as string[]),
    webformRelayAddresses: new Set(configuredRelays as string[]),
    inboxPath: env.EMAIL_IMAP_INBOX_PATH?.trim() || "INBOX",
    sentPath: env.EMAIL_IMAP_SENT_PATH?.trim() || null,
    initialLookbackDays: lookback,
    maximumMessageBytes,
  };
}

export function emailSyncErrorCode(error: unknown): string {
  const message = error instanceof Error ? `${error.name} ${error.message}` : "";
  if (/auth|login|credential/i.test(message)) return "EMAIL_IMAP_AUTH_FAILED";
  if (/sent.*mailbox|mailbox.*not.*found|NONEXISTENT/i.test(message)) return "EMAIL_IMAP_MAILBOX_NOT_FOUND";
  if (/timeout|timed out|ETIMEDOUT/i.test(message)) return "EMAIL_IMAP_TIMEOUT";
  if (/certificate|TLS|SSL/i.test(message)) return "EMAIL_IMAP_TLS_FAILED";
  if (/source.*missing/i.test(message)) return "EMAIL_IMAP_SOURCE_MISSING";
  return "EMAIL_IMAP_SYNC_FAILED";
}

async function syncMailbox(
  database: Client,
  imap: ImapFlow,
  config: ImapRuntimeConfig,
  mailboxRole: EmailMailboxRole,
  mailboxPath: string,
  now: Date,
): Promise<{ fetched: number; stored: number; ignored: number; reviewRequired: number }> {
  const initialSyncAfter = new Date(now.getTime() - config.initialLookbackDays * 24 * 60 * 60 * 1000);
  const cursor = await loadEmailSyncCursor(database, {
    workspaceId: config.workspaceId,
    accountId: config.accountId,
    mailboxRole,
    mailboxPath,
    initialSyncAfter,
  });
  const lock = await imap.getMailboxLock(mailboxPath, { readOnly: true });
  try {
    if (!imap.mailbox) throw new Error("EMAIL_IMAP_MAILBOX_NOT_OPEN");
    const uidValidity = String(imap.mailbox.uidValidity);
    const sameGeneration = cursor.uidValidity === uidValidity;
    const startUid = sameGeneration ? cursor.lastUid + 1 : 1;
    let uids: number[] = [];
    if (sameGeneration && cursor.lastUid >= imap.mailbox.uidNext - 1) {
      uids = [];
    } else {
      const search = await imap.search(
        sameGeneration && cursor.lastUid > 0
          ? { uid: `${startUid}:*` }
          : { since: new Date(cursor.initialSyncAfter) },
        { uid: true },
      );
      if (Array.isArray(search)) uids = search;
    }
    uids = [...new Set(uids)].sort((a, b) => a - b);
    const metrics = { fetched: uids.length, stored: 0, ignored: 0, reviewRequired: 0 };
    let lastUid = sameGeneration ? cursor.lastUid : 0;
    for (let offset = 0; offset < uids.length; offset += 50) {
      const chunk = uids.slice(offset, offset + 50);
      for await (const fetched of imap.fetch(
        chunk,
        { uid: true, internalDate: true, size: true, source: { maxLength: config.maximumMessageBytes } },
        { uid: true },
      )) {
        if (!fetched.source) throw new Error("EMAIL_IMAP_SOURCE_MISSING");
        const parsed = await parseImapMessage({
          source: fetched.source,
          uid: fetched.uid,
          uidValidity,
          mailboxPath,
          mailboxRole,
          ...(fetched.internalDate ? { internalDate: fetched.internalDate } : {}),
          sourceTruncated: typeof fetched.size === "number" && fetched.size > fetched.source.length,
        });
        const result = await ingestEmailMessage(database, {
          workspaceId: config.workspaceId,
          accountId: config.accountId,
          ownAddresses: config.ownAddresses,
          webformRelayAddresses: config.webformRelayAddresses,
          message: parsed,
          receivedAt: now,
        });
        if (!result.duplicate) metrics.stored += 1;
        if (result.analysisStatus === "ignored") metrics.ignored += 1;
        if (result.analysisStatus === "review_required") metrics.reviewRequired += 1;
        lastUid = Math.max(lastUid, fetched.uid);
      }
    }
    await advanceEmailSyncCursor(database, {
      workspaceId: config.workspaceId,
      accountId: config.accountId,
      mailboxRole,
      uidValidity,
      lastUid,
    });
    return metrics;
  } finally {
    lock.release();
  }
}

export async function syncImapEmail(database: Client, env: Environment = process.env, now = new Date()): Promise<{
  inbox: { fetched: number; stored: number; ignored: number; reviewRequired: number };
  sent: { fetched: number; stored: number; ignored: number; reviewRequired: number };
  threadCount: number;
}> {
  const config = readImapRuntimeConfig(env);
  await upsertImapChannelAccount(database, {
    workspaceId: config.workspaceId,
    accountId: config.accountId,
    externalAccountId: config.user,
    displayName: env.EMAIL_IMAP_DISPLAY_NAME?.trim() || `IMAP ${config.user}`,
  });
  const imap = new ImapFlow({
    host: config.host,
    port: config.port,
    secure: config.secure,
    auth: { user: config.user, pass: config.password },
    logger: false,
    disableAutoIdle: true,
    connectionTimeout: 30_000,
    greetingTimeout: 16_000,
    socketTimeout: 120_000,
    maxLiteralSize: config.maximumMessageBytes + 1024 * 1024,
    maxResponseSize: config.maximumMessageBytes + 2 * 1024 * 1024,
  });
  let activeRole: EmailMailboxRole | undefined;
  try {
    await imap.connect();
    const mailboxes = await imap.list();
    const sentPath = config.sentPath ?? mailboxes.find((mailbox) => mailbox.specialUse === "\\Sent")?.path;
    if (!sentPath) throw new Error("EMAIL_IMAP_SENT_MAILBOX_NOT_FOUND");
    activeRole = "inbox";
    const inbox = await syncMailbox(database, imap, config, "inbox", config.inboxPath, now);
    activeRole = "sent";
    const sent = await syncMailbox(database, imap, config, "sent", sentPath, now);
    const threadCount = await refreshEmailThreads(database, config.workspaceId, config.accountId);
    await markImapAccountConnected(database, config.workspaceId, config.accountId);
    await imap.logout();
    return { inbox, sent, threadCount };
  } catch (error) {
    imap.close();
    await recordEmailSyncFailure(database, {
      workspaceId: config.workspaceId,
      accountId: config.accountId,
      ...(activeRole ? { mailboxRole: activeRole } : {}),
      code: emailSyncErrorCode(error),
    });
    throw error;
  }
}
