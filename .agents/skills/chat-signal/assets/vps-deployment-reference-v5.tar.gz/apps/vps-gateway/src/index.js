export default {
  // Legacy queues remain paused and preserved for rollback; never consume old work here.
  async queue(batch) { batch.retryAll({delaySeconds: 43200}); },
  async fetch(request, env) {
    const incoming = new URL(request.url);
    if (!['/healthz'].includes(incoming.pathname) && !incoming.pathname.startsWith('/v1/')) return new Response('Not found', {status:404});
    const target = new URL('http://127.0.0.1:3100');
    target.pathname=incoming.pathname;
    target.search=incoming.search;
    try {
      const upstream=await env.CRM_ORIGIN.fetch(new Request(target,{method:request.method,headers:request.headers,body:request.body,redirect:'manual'}));
      const response=new Response(upstream.body,upstream);
      response.headers.set('cache-control','private, no-store');
      return response;
    }catch{return new Response('CRM temporarily unavailable',{status:502,headers:{'cache-control':'no-store'}});}
  }
};
