import { randomUUID } from "node:crypto";
import type { Client } from "pg";

import type { EmailAddress, EmailMailboxRole, ParsedEmailMessage } from "../../contracts/src/email.ts";
import { formatEmailEvidence, groupEmailThreads, resolveEmailIdentity } from "../../connectors/src/imap-email.ts";

export interface EmailSyncCursor {
  mailboxRole: EmailMailboxRole;
  mailboxPath: string;
  uidValidity: string | null;
  lastUid: number;
  initialSyncAfter: string;
}

export async function upsertImapChannelAccount(client: Client, input: {
  workspaceId: string;
  accountId: string;
  externalAccountId: string;
  displayName: string;
}): Promise<void> {
  const result = await client.query<{ id: string }>(
    `INSERT INTO channel_accounts (
       id, workspace_id, provider, external_account_id, display_name,
       connection_state, created_at
     ) VALUES ($1, $2, 'imap', $3, $4, 'unknown', now())
     ON CONFLICT (id) DO UPDATE SET
       external_account_id = EXCLUDED.external_account_id,
       display_name = EXCLUDED.display_name
     WHERE channel_accounts.workspace_id = EXCLUDED.workspace_id
       AND channel_accounts.provider = 'imap'
     RETURNING id`,
    [input.accountId, input.workspaceId, input.externalAccountId, input.displayName],
  );
  if (result.rows[0]?.id !== input.accountId) throw new Error("EMAIL_IMAP_ACCOUNT_ID_CONFLICT");
}

export async function loadEmailSyncCursor(client: Client, input: {
  workspaceId: string;
  accountId: string;
  mailboxRole: EmailMailboxRole;
  mailboxPath: string;
  initialSyncAfter: Date;
}): Promise<EmailSyncCursor> {
  const result = await client.query<{
    mailbox_role: EmailMailboxRole;
    mailbox_path: string;
    uid_validity: string | null;
    last_uid: string;
    initial_sync_after: Date | string;
  }>(
    `INSERT INTO email_sync_cursors (
       workspace_id, channel_account_id, mailbox_role, mailbox_path,
       uid_validity, last_uid, initial_sync_after, updated_at
     ) VALUES ($1, $2, $3, $4, NULL, 0, $5, now())
     ON CONFLICT (workspace_id, channel_account_id, mailbox_role) DO UPDATE SET
       uid_validity = CASE
         WHEN email_sync_cursors.mailbox_path = EXCLUDED.mailbox_path
           THEN email_sync_cursors.uid_validity ELSE NULL END,
       last_uid = CASE
         WHEN email_sync_cursors.mailbox_path = EXCLUDED.mailbox_path
           THEN email_sync_cursors.last_uid ELSE 0 END,
       mailbox_path = EXCLUDED.mailbox_path,
       updated_at = now()
     RETURNING mailbox_role, mailbox_path, uid_validity, last_uid, initial_sync_after`,
    [input.workspaceId, input.accountId, input.mailboxRole, input.mailboxPath, input.initialSyncAfter.toISOString()],
  );
  const row = result.rows[0]!;
  return {
    mailboxRole: row.mailbox_role,
    mailboxPath: row.mailbox_path,
    uidValidity: row.uid_validity,
    lastUid: Number(row.last_uid),
    initialSyncAfter: new Date(row.initial_sync_after).toISOString(),
  };
}

export async function advanceEmailSyncCursor(client: Client, input: {
  workspaceId: string;
  accountId: string;
  mailboxRole: EmailMailboxRole;
  uidValidity: string;
  lastUid: number;
}): Promise<void> {
  await client.query(
    `UPDATE email_sync_cursors
     SET uid_validity = $4, last_uid = $5, last_successful_at = now(),
         last_error_code = NULL, updated_at = now()
     WHERE workspace_id = $1 AND channel_account_id = $2 AND mailbox_role = $3`,
    [input.workspaceId, input.accountId, input.mailboxRole, input.uidValidity, input.lastUid],
  );
}

export async function recordEmailSyncFailure(client: Client, input: {
  workspaceId: string;
  accountId: string;
  mailboxRole?: EmailMailboxRole;
  code: string;
}): Promise<void> {
  await client.query(
    `UPDATE channel_accounts
     SET connection_state = 'degraded', gap_since_at = COALESCE(gap_since_at, now())
     WHERE workspace_id = $1 AND id = $2 AND provider = 'imap'`,
    [input.workspaceId, input.accountId],
  );
  if (input.mailboxRole) {
    await client.query(
      `UPDATE email_sync_cursors SET last_error_code = $4, updated_at = now()
       WHERE workspace_id = $1 AND channel_account_id = $2 AND mailbox_role = $3`,
      [input.workspaceId, input.accountId, input.mailboxRole, input.code.slice(0, 120)],
    );
  }
}

function parseJson<T>(value: T | string): T {
  return typeof value === "string" ? JSON.parse(value) as T : value;
}

export async function ingestEmailMessage(client: Client, input: {
  workspaceId: string;
  accountId: string;
  ownAddresses: ReadonlySet<string>;
  webformRelayAddresses?: ReadonlySet<string>;
  message: ParsedEmailMessage;
  receivedAt?: Date;
}): Promise<{ emailMessageId: string; messageId: string | null; duplicate: boolean; analysisStatus: string }> {
  const references = [...new Set([
    ...input.message.references,
    ...(input.message.inReplyTo ? [input.message.inReplyTo] : []),
  ])];
  const referenced = references.length ? await client.query<{ primary_identity_address: string }>(
    `SELECT DISTINCT primary_identity_address
     FROM email_messages
     WHERE workspace_id = $1 AND channel_account_id = $2
       AND rfc_message_id = ANY($3::text[])
       AND analysis_status = 'eligible' AND primary_identity_address IS NOT NULL`,
    [input.workspaceId, input.accountId, references],
  ) : { rows: [] };
  const resolution = resolveEmailIdentity({
    message: input.message,
    ownAddresses: input.ownAddresses,
    ...(input.webformRelayAddresses ? { webformRelayAddresses: input.webformRelayAddresses } : {}),
    referencedIdentityAddresses: referenced.rows.map((row) => row.primary_identity_address),
  });
  const knownReferences = references.length ? await client.query<{ rfc_message_id: string }>(
    `SELECT rfc_message_id FROM email_messages
     WHERE workspace_id = $1 AND channel_account_id = $2
       AND rfc_message_id = ANY($3::text[])`,
    [input.workspaceId, input.accountId, references],
  ) : { rows: [] };
  const backgroundComplete = references.every((reference) => knownReferences.rows.some((row) => row.rfc_message_id === reference));
  const emailMessageId = randomUUID();
  const receivedAt = input.receivedAt ?? new Date();

  await client.query("BEGIN");
  try {
    const canonical = await client.query<{ id: string; message_id: string | null; analysis_status: string }>(
      `INSERT INTO email_messages (
         id, workspace_id, channel_account_id, message_id, rfc_message_id,
         direction, primary_identity_address, analysis_status, analysis_reason,
         classification, subject, from_addresses, to_addresses, cc_addresses, reply_to_addresses,
         in_reply_to, reference_ids, thread_key, background_complete, body_text,
         attachments, source_truncated, source_sha256, occurred_at, first_seen_at, last_seen_at
       ) VALUES (
         $1, $2, $3, NULL, $4, $5, $6, $7, $8, $9, $10,
         $11::jsonb, $12::jsonb, $13::jsonb, $14::jsonb, $15, $16::jsonb, $17, $18,
         $19, $20::jsonb, $21, $22, $23, $24, $24
       )
       ON CONFLICT (workspace_id, channel_account_id, rfc_message_id) DO UPDATE SET
         last_seen_at = EXCLUDED.last_seen_at
       RETURNING id, message_id, analysis_status`,
      [
        emailMessageId, input.workspaceId, input.accountId, input.message.rfcMessageId,
        resolution.direction, resolution.address, resolution.status, resolution.reason,
        input.message.classification, input.message.subject,
        JSON.stringify(input.message.from), JSON.stringify(input.message.to), JSON.stringify(input.message.cc), JSON.stringify(input.message.replyTo),
        input.message.inReplyTo, JSON.stringify(input.message.references), input.message.rfcMessageId,
        backgroundComplete, input.message.text, JSON.stringify(input.message.attachments),
        input.message.sourceTruncated, input.message.sourceSha256, input.message.occurredAt, receivedAt.toISOString(),
      ],
    );
    const row = canonical.rows[0]!;
    const duplicate = row.id !== emailMessageId;
    await client.query(
      `INSERT INTO email_message_copies (
         workspace_id, channel_account_id, email_message_id, mailbox_role,
         mailbox_path, uid_validity, uid, first_seen_at
       ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT (workspace_id, channel_account_id, mailbox_path, uid_validity, uid)
       DO NOTHING`,
      [input.workspaceId, input.accountId, row.id, input.message.mailboxRole,
        input.message.mailboxPath, input.message.uidValidity, input.message.uid, receivedAt.toISOString()],
    );

    let messageId = row.message_id;
    if (!messageId && row.analysis_status === "eligible" && resolution.address) {
      const identity = await client.query<{ id: string }>(
        `INSERT INTO channel_identities (
           id, workspace_id, channel_account_id, external_chat_id,
           display_name, created_at
         ) VALUES ($1, $2, $3, $4, $5, now())
         ON CONFLICT (workspace_id, channel_account_id, external_chat_id) DO UPDATE SET
           display_name = COALESCE(channel_identities.display_name, EXCLUDED.display_name)
         RETURNING id`,
        [randomUUID(), input.workspaceId, input.accountId, resolution.address,
          [...input.message.from, ...input.message.replyTo].find((address) => address.address === resolution.address)?.name ?? null],
      );
      messageId = randomUUID();
      const rendered = formatEmailEvidence(input.message, backgroundComplete, input.message.rfcMessageId);
      const inserted = await client.query<{ id: string }>(
        `INSERT INTO messages (
           id, workspace_id, channel_account_id, identity_id, external_message_id,
           direction, occurred_at, received_at, message_type, body_text,
           quoted_external_message_id, created_at
         ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 'email', $9, $10, now())
         ON CONFLICT (workspace_id, channel_account_id, external_message_id)
         DO UPDATE SET external_message_id = EXCLUDED.external_message_id
         RETURNING id`,
        [messageId, input.workspaceId, input.accountId, identity.rows[0]!.id,
          `email:${input.message.rfcMessageId}`, resolution.direction, input.message.occurredAt,
          receivedAt.toISOString(), rendered,
          input.message.inReplyTo ? `email:${input.message.inReplyTo}` : null],
      );
      messageId = inserted.rows[0]!.id;
      await client.query("UPDATE email_messages SET message_id = $2 WHERE id = $1", [row.id, messageId]);
      const materialAttachments = input.message.attachments.filter((attachment) => !attachment.related);
      for (const [index, attachment] of materialAttachments.entries()) {
        await client.query(
          `INSERT INTO attachments (
             id, workspace_id, message_id, external_attachment_id, mime_type,
             file_name, size_bytes, sha256, processing_status, gap_reason, created_at
           ) VALUES ($1, $2, $3, $4, $5, $6, $7, NULL, 'blocked',
                     'EMAIL_ATTACHMENT_NOT_EXTRACTED', now())
           ON CONFLICT (workspace_id, message_id, external_attachment_id) DO NOTHING`,
          [randomUUID(), input.workspaceId, messageId,
            `email:${index}:${attachment.contentId ?? attachment.fileName ?? "attachment"}`,
            attachment.mimeType, attachment.fileName, attachment.sizeBytes],
        );
      }
      if (input.message.sourceTruncated) {
        await client.query(
          `INSERT INTO attachments (
             id, workspace_id, message_id, external_attachment_id, mime_type,
             file_name, size_bytes, sha256, processing_status, gap_reason, created_at
           ) VALUES ($1, $2, $3, 'email:source-truncated', 'message/rfc822',
                     NULL, NULL, NULL, 'blocked', 'EMAIL_SOURCE_TRUNCATED', now())
           ON CONFLICT (workspace_id, message_id, external_attachment_id) DO NOTHING`,
          [randomUUID(), input.workspaceId, messageId],
        );
      }
    }
    await client.query("COMMIT");
    return { emailMessageId: row.id, messageId, duplicate, analysisStatus: row.analysis_status };
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }
}

interface StoredEmailRow {
  id: string;
  message_id: string | null;
  rfc_message_id: string;
  in_reply_to: string | null;
  reference_ids: string[] | string;
  occurred_at: Date | string;
  subject: string;
  from_addresses: EmailAddress[] | string;
  to_addresses: EmailAddress[] | string;
  cc_addresses: EmailAddress[] | string;
  reply_to_addresses: EmailAddress[] | string;
  body_text: string | null;
  classification: ParsedEmailMessage["classification"];
  source_truncated: boolean;
  source_sha256: string;
  attachments: ParsedEmailMessage["attachments"] | string;
}

export async function refreshEmailThreads(client: Client, workspaceId: string, accountId: string): Promise<number> {
  const rows = await client.query<StoredEmailRow>(
    `SELECT id, message_id, rfc_message_id, in_reply_to, reference_ids,
            occurred_at, subject, from_addresses, to_addresses, cc_addresses, reply_to_addresses,
            body_text, classification, source_truncated, source_sha256, attachments
     FROM email_messages
     WHERE workspace_id = $1 AND channel_account_id = $2
     ORDER BY occurred_at, rfc_message_id`,
    [workspaceId, accountId],
  );
  const grouped = groupEmailThreads(rows.rows.map((row) => ({
    rfcMessageId: row.rfc_message_id,
    inReplyTo: row.in_reply_to,
    references: parseJson(row.reference_ids),
    occurredAt: new Date(row.occurred_at).toISOString(),
  })));
  await client.query("BEGIN");
  try {
    for (const row of rows.rows) {
      const group = grouped.get(row.rfc_message_id)!;
      await client.query(
        "UPDATE email_messages SET thread_key = $2, background_complete = $3 WHERE id = $1",
        [row.id, group.threadKey, group.backgroundComplete],
      );
      if (row.message_id) {
        const message: ParsedEmailMessage = {
          uid: 1, uidValidity: "stored", mailboxPath: "stored", mailboxRole: "inbox",
          rfcMessageId: row.rfc_message_id,
          occurredAt: new Date(row.occurred_at).toISOString(),
          subject: row.subject,
          from: parseJson(row.from_addresses), to: parseJson(row.to_addresses), cc: parseJson(row.cc_addresses),
          replyTo: parseJson(row.reply_to_addresses),
          inReplyTo: row.in_reply_to, references: parseJson(row.reference_ids), text: row.body_text,
          classification: row.classification, sourceTruncated: row.source_truncated,
          sourceSha256: row.source_sha256,
          attachments: parseJson(row.attachments),
        };
        await client.query(
          "UPDATE messages SET body_text = $2 WHERE id = $1 AND message_type = 'email'",
          [row.message_id, formatEmailEvidence(message, group.backgroundComplete, group.threadKey)],
        );
      }
    }
    await client.query("COMMIT");
    return rows.rowCount ?? 0;
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  }
}

export async function markImapAccountConnected(client: Client, workspaceId: string, accountId: string): Promise<void> {
  await client.query(
    `UPDATE channel_accounts
     SET connection_state = 'connected', last_seen_at = now(), gap_since_at = NULL
     WHERE workspace_id = $1 AND id = $2 AND provider = 'imap'`,
    [workspaceId, accountId],
  );
}
