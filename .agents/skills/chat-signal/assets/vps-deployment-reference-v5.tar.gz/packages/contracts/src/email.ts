export type EmailMailboxRole = "inbox" | "sent";
export type EmailClassification = "human" | "bulk" | "bounce" | "system";
export type EmailAnalysisStatus = "eligible" | "ignored" | "review_required";

export interface EmailAddress {
  address: string;
  name: string | null;
}

export interface ParsedEmailMessage {
  uid: number;
  uidValidity: string;
  mailboxPath: string;
  mailboxRole: EmailMailboxRole;
  rfcMessageId: string;
  occurredAt: string;
  subject: string;
  from: EmailAddress[];
  to: EmailAddress[];
  cc: EmailAddress[];
  replyTo: EmailAddress[];
  inReplyTo: string | null;
  references: string[];
  text: string | null;
  classification: EmailClassification;
  sourceTruncated: boolean;
  sourceSha256: string;
  attachments: Array<{
    contentId: string | null;
    fileName: string | null;
    mimeType: string | null;
    sizeBytes: number | null;
    related: boolean;
  }>;
}

export interface ResolvedEmailIdentity {
  status: EmailAnalysisStatus;
  direction: "inbound" | "outbound";
  address: string | null;
  reason: string | null;
}
