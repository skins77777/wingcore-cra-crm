import { createHash } from "node:crypto";
import { simpleParser, type AddressObject, type ParsedMail } from "mailparser";

import type {
  EmailAddress,
  EmailClassification,
  EmailMailboxRole,
  ParsedEmailMessage,
  ResolvedEmailIdentity,
} from "../../contracts/src/email.ts";

const messageIdPattern = /<[^<>\s]+>/g;

export function normalizeEmailAddress(value: string): string | null {
  const normalized = value.normalize("NFKC").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) return null;
  return normalized;
}

export function normalizeMessageId(value: string | null | undefined): string | null {
  if (!value) return null;
  const match = value.match(messageIdPattern)?.[0] ?? value.trim();
  const normalized = match.replace(/^<|>$/g, "").normalize("NFKC").trim().toLowerCase();
  return normalized && !/\s/.test(normalized) ? normalized : null;
}

export function messageIdList(value: unknown): string[] {
  const raw = Array.isArray(value) ? value.join(" ") : typeof value === "string" ? value : "";
  const candidates = raw.match(messageIdPattern) ?? raw.split(/\s+/);
  return [...new Set(candidates.map((item) => normalizeMessageId(item)).filter((item): item is string => !!item))];
}

function addresses(value: AddressObject | AddressObject[] | undefined): EmailAddress[] {
  const groups = value ? (Array.isArray(value) ? value : [value]) : [];
  const result: EmailAddress[] = [];
  const visit = (entry: AddressObject["value"][number]) => {
    if (entry.group) entry.group.forEach(visit);
    const address = entry.address ? normalizeEmailAddress(entry.address) : null;
    if (address) result.push({ address, name: entry.name?.normalize("NFKC").trim() || null });
  };
  groups.flatMap((group) => group.value).forEach(visit);
  return [...new Map(result.map((item) => [item.address, item])).values()];
}

function header(mail: ParsedMail, name: string): string {
  const value = mail.headers.get(name);
  if (Array.isArray(value)) return value.map((item) => typeof item === "string" ? item : typeof item === "object" && item && "value" in item ? String(item.value) : "").join(", ");
  if (typeof value === "string") return value;
  return typeof value === "object" && value && "value" in value ? String(value.value) : "";
}

export function classifyEmail(mail: ParsedMail): EmailClassification {
  const from = addresses(mail.from).map((item) => item.address).join(" ");
  const autoSubmitted = header(mail, "auto-submitted").toLowerCase();
  const precedence = header(mail, "precedence").toLowerCase();
  const listId = header(mail, "list-id");
  const contentType = header(mail, "content-type").toLowerCase();
  if (/mailer-daemon|postmaster|mail-daemon/.test(from) || contentType.includes("multipart/report") || header(mail, "x-failed-recipients")) return "bounce";
  if (autoSubmitted && autoSubmitted !== "no") return "system";
  if (listId || /\b(?:bulk|list|junk)\b/.test(precedence) || header(mail, "list-unsubscribe")) return "bulk";
  return "human";
}

function fallbackMessageId(input: { mailboxPath: string; uidValidity: string; uid: number; source: Buffer }): string {
  return `missing-${createHash("sha256").update(input.mailboxPath).update("\0").update(input.uidValidity).update("\0").update(String(input.uid)).update("\0").update(input.source).digest("hex")}`;
}

export async function parseImapMessage(input: {
  source: Buffer;
  uid: number;
  uidValidity: bigint | string;
  mailboxPath: string;
  mailboxRole: EmailMailboxRole;
  internalDate?: Date | string;
  sourceTruncated?: boolean;
}): Promise<ParsedEmailMessage> {
  if (!Number.isSafeInteger(input.uid) || input.uid <= 0) throw new TypeError("Invalid IMAP UID");
  const mail = await simpleParser(input.source, { skipHtmlToText: false, skipTextToHtml: true });
  const uidValidity = String(input.uidValidity);
  const occurred = mail.date ?? (input.internalDate ? new Date(input.internalDate) : new Date());
  if (Number.isNaN(occurred.getTime())) throw new TypeError("Invalid email date");
  const rfcMessageId = normalizeMessageId(mail.messageId) ?? fallbackMessageId({
    mailboxPath: input.mailboxPath,
    uidValidity,
    uid: input.uid,
    source: input.source,
  });
  const inReplyTo = normalizeMessageId(mail.inReplyTo);
  const references = messageIdList(mail.references);
  return {
    uid: input.uid,
    uidValidity,
    mailboxPath: input.mailboxPath,
    mailboxRole: input.mailboxRole,
    rfcMessageId,
    occurredAt: occurred.toISOString(),
    subject: (mail.subject ?? "").normalize("NFKC").trim(),
    from: addresses(mail.from),
    to: addresses(mail.to),
    cc: addresses(mail.cc),
    replyTo: addresses(mail.replyTo),
    inReplyTo,
    references,
    text: mail.text?.normalize("NFKC").trim() || null,
    classification: classifyEmail(mail),
    sourceTruncated: input.sourceTruncated ?? false,
    sourceSha256: createHash("sha256").update(input.source).digest("hex"),
    attachments: mail.attachments.map((attachment) => ({
      contentId: attachment.contentId ?? null,
      fileName: attachment.filename?.normalize("NFKC").trim() || null,
      mimeType: attachment.contentType || null,
      sizeBytes: Number.isSafeInteger(attachment.size) ? attachment.size : null,
      related: attachment.related,
    })),
  };
}

export function resolveEmailIdentity(input: {
  message: ParsedEmailMessage;
  ownAddresses: ReadonlySet<string>;
  webformRelayAddresses?: ReadonlySet<string>;
  referencedIdentityAddresses?: readonly string[];
}): ResolvedEmailIdentity {
  const own = new Set([...input.ownAddresses].map(normalizeEmailAddress).filter((item): item is string => !!item));
  const trustedRelays = new Set([...(input.webformRelayAddresses ?? [])].map(normalizeEmailAddress).filter((item): item is string => !!item));
  const from = input.message.from.map((item) => item.address);
  const ownSender = from.some((address) => own.has(address));
  const ownRecipientsOnly = input.message.to.length > 0 && input.message.to.every((item) => own.has(item.address));
  const externalReplyTo = [...new Set(input.message.replyTo.map((item) => item.address).filter((address) => !own.has(address)))];
  const bodyEmails = new Set((input.message.text?.match(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi) ?? [])
    .map(normalizeEmailAddress).filter((item): item is string => !!item && !own.has(item)));
  const webformIdentity = input.message.mailboxRole === "inbox"
    && ownSender
    && ownRecipientsOnly
    && from.some((address) => trustedRelays.has(address))
    && externalReplyTo.length === 1
    && bodyEmails.has(externalReplyTo[0]!);
  const direction = webformIdentity ? "inbound" : input.message.mailboxRole === "sent" || ownSender ? "outbound" : "inbound";
  if (input.message.classification !== "human") {
    return { status: "ignored", direction, address: null, reason: `EMAIL_${input.message.classification.toUpperCase()}` };
  }
  if (webformIdentity) {
    return { status: "eligible", direction: "inbound", address: externalReplyTo[0]!, reason: null };
  }
  if (direction === "inbound") {
    const externalSenders = [...new Set(from.filter((address) => !own.has(address)))];
    if (externalSenders.length === 1) return { status: "eligible", direction, address: externalSenders[0]!, reason: null };
    return { status: "review_required", direction, address: null, reason: "EMAIL_SENDER_AMBIGUOUS" };
  }
  const references = [...new Set((input.referencedIdentityAddresses ?? []).map(normalizeEmailAddress).filter((item): item is string => !!item))];
  if (references.length === 1) return { status: "eligible", direction, address: references[0]!, reason: null };
  const directRecipients = [...new Set(input.message.to.map((item) => item.address).filter((address) => !own.has(address)))];
  if (directRecipients.length === 1) return { status: "eligible", direction, address: directRecipients[0]!, reason: null };
  return { status: "review_required", direction, address: null, reason: directRecipients.length ? "EMAIL_MULTIPLE_TO_RECIPIENTS" : "EMAIL_RECIPIENT_UNRESOLVED" };
}

export function formatEmailEvidence(message: ParsedEmailMessage, backgroundComplete: boolean, threadKey?: string): string {
  const from = message.from.map((item) => item.name ? `${item.name} <${item.address}>` : item.address).join(", ");
  const to = message.to.map((item) => item.name ? `${item.name} <${item.address}>` : item.address).join(", ");
  const replyTo = message.replyTo.map((item) => item.name ? `${item.name} <${item.address}>` : item.address).join(", ");
  const lines = [
    `[邮件主题] ${message.subject || "（无主题）"}`,
    `[发件人] ${from || "（缺失）"}`,
    `[直接收件人] ${to || "（缺失）"}`,
    `[回复地址] ${replyTo || "（缺失）"}`,
    ...(threadKey ? [`[邮件会话ID] ${threadKey}`] : []),
    `[邮件会话背景] ${backgroundComplete ? "引用链在已同步范围内完整" : "30天同步范围外或引用邮件缺失；不得猜测缺失背景"}`,
    "[正文]",
    message.text ?? "（无可解析纯文本正文）",
  ];
  return lines.join("\n");
}

export interface ThreadableEmail {
  rfcMessageId: string;
  inReplyTo: string | null;
  references: string[];
  occurredAt: string;
}

export function groupEmailThreads(messages: readonly ThreadableEmail[]): Map<string, { threadKey: string; backgroundComplete: boolean }> {
  const byId = new Map(messages.map((message) => [message.rfcMessageId, message]));
  const parent = new Map(messages.map((message) => [message.rfcMessageId, message.rfcMessageId]));
  const find = (id: string): string => {
    const current = parent.get(id)!;
    if (current === id) return id;
    const root = find(current); parent.set(id, root); return root;
  };
  const union = (left: string, right: string) => {
    const a = find(left), b = find(right);
    if (a !== b) parent.set(a, b);
  };
  for (const message of messages) {
    for (const reference of [...message.references, ...(message.inReplyTo ? [message.inReplyTo] : [])]) {
      if (byId.has(reference)) union(message.rfcMessageId, reference);
    }
  }
  const components = new Map<string, ThreadableEmail[]>();
  for (const message of messages) {
    const root = find(message.rfcMessageId);
    components.set(root, [...(components.get(root) ?? []), message]);
  }
  const result = new Map<string, { threadKey: string; backgroundComplete: boolean }>();
  for (const component of components.values()) {
    const ordered = [...component].sort((a, b) => Date.parse(a.occurredAt) - Date.parse(b.occurredAt) || a.rfcMessageId.localeCompare(b.rfcMessageId));
    const key = ordered[0]!.rfcMessageId;
    for (const message of component) {
      const required = [...message.references, ...(message.inReplyTo ? [message.inReplyTo] : [])];
      result.set(message.rfcMessageId, { threadKey: key, backgroundComplete: required.every((reference) => byId.has(reference)) });
    }
  }
  return result;
}
