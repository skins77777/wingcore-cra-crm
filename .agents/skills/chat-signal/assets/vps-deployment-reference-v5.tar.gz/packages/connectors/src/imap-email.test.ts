import assert from "node:assert/strict";
import test from "node:test";

import { formatEmailEvidence, groupEmailThreads, parseImapMessage, resolveEmailIdentity } from "./imap-email.ts";

test("parses and normalizes a MIME email without using the subject as a thread key", async () => {
  const message = await parseImapMessage({
    source: Buffer.from([
      "Message-ID: <Order-1@Example.COM>",
      "Date: Fri, 25 Sep 2026 10:00:00 +0800",
      "From: Buyer <BUYER@example.com>",
      "To: Sales <sales@our.example>",
      "Cc: Observer <observer@example.com>",
      "Subject: Fresh flowers",
      "Content-Type: text/plain; charset=utf-8",
      "",
      "Please quote 10 boxes.",
    ].join("\r\n")),
    uid: 7,
    uidValidity: 99n,
    mailboxPath: "INBOX",
    mailboxRole: "inbox",
  });
  assert.equal(message.rfcMessageId, "order-1@example.com");
  assert.deepEqual(message.from.map((item) => item.address), ["buyer@example.com"]);
  assert.deepEqual(message.cc.map((item) => item.address), ["observer@example.com"]);
  assert.equal(message.classification, "human");
  assert.match(message.sourceSha256, /^[0-9a-f]{64}$/);
});

test("uses sender for inbound and never promotes cc to the customer identity", async () => {
  const message = await parseImapMessage({
    source: Buffer.from("Message-ID: <m1@x>\r\nFrom: buyer@example.com\r\nTo: sales@our.example\r\nCc: boss@example.com\r\n\r\nHello"),
    uid: 1, uidValidity: "1", mailboxPath: "INBOX", mailboxRole: "inbox",
  });
  assert.deepEqual(resolveEmailIdentity({ message, ownAddresses: new Set(["sales@our.example"]) }), {
    status: "eligible", direction: "inbound", address: "buyer@example.com", reason: null,
  });
});

test("requires review for an outbound email with multiple direct recipients unless reply headers resolve the identity", async () => {
  const message = await parseImapMessage({
    source: Buffer.from("Message-ID: <m2@x>\r\nFrom: sales@our.example\r\nTo: a@example.com, b@example.com\r\n\r\nHello"),
    uid: 2, uidValidity: "1", mailboxPath: "Sent", mailboxRole: "sent",
  });
  assert.equal(resolveEmailIdentity({ message, ownAddresses: new Set(["sales@our.example"]) }).status, "review_required");
  assert.equal(resolveEmailIdentity({ message, ownAddresses: new Set(["sales@our.example"]), referencedIdentityAddresses: ["a@example.com"] }).address, "a@example.com");
});

test("treats only a trusted self-relayed website form as an inbound customer", async () => {
  const message = await parseImapMessage({
    source: Buffer.from([
      "Message-ID: <webform@x>",
      "From: Website <sales@our.example>",
      "To: Sales <sales@our.example>",
      "Reply-To: Visitor <visitor@example.com>",
      "Subject: Website inquiry",
      "",
      "Source: Website",
      "Name: Visitor",
      "Email: visitor@example.com",
      "WhatsApp / Telegram: +1 555 0100",
      "Inquiry details: Please quote 20 boxes.",
    ].join("\r\n")),
    uid: 20, uidValidity: "1", mailboxPath: "INBOX", mailboxRole: "inbox",
  });
  assert.deepEqual(message.replyTo.map((item) => item.address), ["visitor@example.com"]);
  assert.deepEqual(resolveEmailIdentity({
    message,
    ownAddresses: new Set(["sales@our.example"]),
    webformRelayAddresses: new Set(["sales@our.example"]),
  }), {
    status: "eligible", direction: "inbound", address: "visitor@example.com", reason: null,
  });
  assert.equal(resolveEmailIdentity({
    message,
    ownAddresses: new Set(["sales@our.example"]),
  }).reason, "EMAIL_RECIPIENT_UNRESOLVED");
});

test("does not trust a self-relayed Reply-To that disagrees with the body email", async () => {
  const message = await parseImapMessage({
    source: Buffer.from("Message-ID: <spoof@x>\r\nFrom: sales@our.example\r\nTo: sales@our.example\r\nReply-To: attacker@example.com\r\n\r\nEmail: customer@example.com"),
    uid: 21, uidValidity: "1", mailboxPath: "INBOX", mailboxRole: "inbox",
  });
  assert.equal(resolveEmailIdentity({
    message,
    ownAddresses: new Set(["sales@our.example"]),
    webformRelayAddresses: new Set(["sales@our.example"]),
  }).status, "review_required");
});

test("filters bounce and bulk mail before analysis", async () => {
  const bounce = await parseImapMessage({
    source: Buffer.from("Message-ID: <bounce@x>\r\nFrom: MAILER-DAEMON@example.com\r\nTo: sales@our.example\r\nContent-Type: multipart/report; boundary=x\r\n\r\n--x--"),
    uid: 3, uidValidity: "1", mailboxPath: "INBOX", mailboxRole: "inbox",
  });
  assert.deepEqual(resolveEmailIdentity({ message: bounce, ownAddresses: new Set(["sales@our.example"]) }), {
    status: "ignored", direction: "inbound", address: null, reason: "EMAIL_BOUNCE",
  });
});

test("groups only by Message-ID reply graph and marks unavailable ancestors", () => {
  const grouped = groupEmailThreads([
    { rfcMessageId: "a@x", inReplyTo: null, references: [], occurredAt: "2026-09-01T00:00:00.000Z" },
    { rfcMessageId: "b@x", inReplyTo: "a@x", references: ["a@x"], occurredAt: "2026-09-02T00:00:00.000Z" },
    { rfcMessageId: "c@x", inReplyTo: "missing@x", references: ["missing@x"], occurredAt: "2026-09-03T00:00:00.000Z" },
    { rfcMessageId: "d@x", inReplyTo: null, references: [], occurredAt: "2026-09-04T00:00:00.000Z" },
  ]);
  assert.equal(grouped.get("b@x")?.threadKey, "a@x");
  assert.equal(grouped.get("b@x")?.backgroundComplete, true);
  assert.equal(grouped.get("c@x")?.backgroundComplete, false);
  assert.notEqual(grouped.get("c@x")?.threadKey, grouped.get("d@x")?.threadKey);
});

test("renders an explicit missing-background marker in model evidence", async () => {
  const message = await parseImapMessage({
    source: Buffer.from("Message-ID: <m3@x>\r\nFrom: buyer@example.com\r\nTo: sales@our.example\r\n\r\nContinue the prior order"),
    uid: 4, uidValidity: "1", mailboxPath: "INBOX", mailboxRole: "inbox",
  });
  assert.match(formatEmailEvidence(message, false), /30天同步范围外或引用邮件缺失/);
});
